package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.nativead.NativeAd;

import java.util.ArrayList;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.Cashinflatefb;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class veriloandetails extends BaseActivity_Lang {
    public void backkk(View view) {
        Log.e("dd", "");

        onBackPressed();


    }
    @Override
    public void onBackPressed() {
        MyApp.show_ad(veriloandetails.this, new CashonAdListner() {
            @Override
            public void onsuccess() {
                veriloandetails.super.onBackPressed();

            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_veriloandetails);
        //banner
        String bb = MyApp.nativeAd(veriloandetails.this);

        if (bb.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(veriloandetails.this).is_ad_status()) {
                String id_banner = CashAppManager.getInstance(veriloandetails.this).get_amob_banner_id();

                if (!id_banner.equalsIgnoreCase("")) {
                    AdView adView = new AdView(this);
                    adView.setAdSize(AdSize.BANNER);
                    adView.setAdUnitId(id_banner);
                    LinearLayout succes_banner = findViewById(R.id.succes_banner);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                    succes_banner.addView(adView);
                }
            }
        } else if (bb.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(veriloandetails.this).is_ad_status_fb()) {
                LinearLayout succes_banner = findViewById(R.id.succes_banner);
                String id_banner = CashAppManager.getInstance(veriloandetails.this).get_fb_banner_id();
                com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, id_banner, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                succes_banner.addView(adView);
                adView.loadAd();
            }
        }
        ///end

        //Nativee
        String aa = MyApp.nativeAd(veriloandetails.this);
        TemplateView template = findViewById(R.id.my_template_success);
        template.setVisibility(View.INVISIBLE);
        if (aa.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(veriloandetails.this).is_ad_status_Admob()) {

                String id_nativ = CashAppManager.getInstance(veriloandetails.this).get_amob_nativ_id();

                if (!id_nativ.equalsIgnoreCase("")) {

                    AdLoader adLoader = new AdLoader.Builder(this, id_nativ)
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(NativeAd nativeAd) {
                                    template.setVisibility(View.VISIBLE);
                                    NativeTemplateStyle styles = new
                                            NativeTemplateStyle.Builder().build();

                                    template.setStyles(styles);
                                    template.setNativeAd(nativeAd);
                                }
                            })
                            .build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
        } else if (aa.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(veriloandetails.this).is_ad_status_fb()) {
                template.removeAllViews();

                com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(this, CashAppManager.getInstance(veriloandetails.this).get_amob_facebook_id());

                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        new Cashinflatefb().inflatefb(nativeAd, template, veriloandetails.this);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                // Request an ad
                nativeAd.loadAd(
                        nativeAd.buildLoadAdConfig()
                                .withAdListener(nativeAdListener)
                                .build());


            }
        }

        ///
        RecyclerView Amount_list = findViewById(R.id.loan_amont);
        Amount_list.setHasFixedSize(true);
        Amount_list.setLayoutManager(new LinearLayoutManager(this, 1, false));
        int Posivalu = getIntent().getIntExtra("posi", 0);
        ArrayList<Recyamount> ammountarry = new ArrayList();
        if (Posivalu == 1) {
            ammountarry.add(new Recyamount("StuCred", "Rs 10,000", "91 Days", "0%", "2%", "Are you a College Student in India? In need of an immediate loan? You\u2019ve come to the right place. Introducing StuCred, India\u2019s most trustworthy Real-Time Student Credit app! StuCred is a secure, digital platform that offers short-term, interest-free, \u201cpocket- money\u201d credit with the objective to Educate and Empower Indian College Students, the leaders of tomorrow. All, while building your credit score by reporting to All Credit Bureaus.\n\n"));
            ammountarry.add(new Recyamount("Stashfin", "Rs 10,000 to 1 Lakhs", "6 to 36 months", "5%", "2%", "Instant Credit Line Card & Personal Loan App\n\n"));
            ammountarry.add(new Recyamount("SmartCoin", "Rs 1 Lakh to 5 Lakh", "12 months to 60 months", "0%_05%", "0%-2.5%", "All Loan are sanctioned & approved by NBFCs/Banks registered with RBI and their details are shown upfront during Loan application. Details are also available in the Loan Agreements.\n\n"));
            ammountarry.add(new Recyamount("MoneyTap", "Rs 5 Lakh and Above", "48 months to 72 months", "2%", "2%", "Loan app for salaried employees in India - Minimum salary = 30,000 per month.\n\n"));
        } else if (Posivalu == 2) {
            ammountarry.add(new Recyamount("GoToCash", "Rs 10,000 to 50,000", "92 days to 365 Days", "0.095% per", "10%", "Instant Personal Loan Platform\n\n\n"));
            ammountarry.add(new Recyamount("Mi Credit", "Rs 50,000 to 1 Lakh", "12 to 36 months", "10%", "2%", "It offers service to users over 21 years old and allows you to apply for a loan in four quick steps and get money within minutes. The application process is completely digital and hassle-free, and can be completed with the help of your mobile phone anywhere, even when you are sitting at your home, office or commuting. You may use the loan funds for any personal or business requirements. You have the flexibility to choose EMI tenure, so that it is convenient for you to pay the EMIs! "));
            ammountarry.add(new Recyamount("Cash Been", "Rs 1 Lakh to 5 Lakh", "12 to 60 months", "2%", "1%", "India\u2019s leading digital lending mobile based personal loans platform. CashBean is a product of P C Financial Services Private Limited, registered under RBI. We aim to meet customer\u2019s financial needs for various requirements ranging from purchase of mobile phones, medical needs, bill payments etc.\n\n"));
            ammountarry.add(new Recyamount("TrueBalance", "Rs 5 Lakh to Above", "12 to 120 months", "5%", "3%", "Digital lending and financial services platform with licensed entities\n\n"));
        }
        if (Posivalu == 3) {
            ammountarry.add(new Recyamount("Fairmoney", "Rs 50,000 to 5 Lakh", "6 to 60 Month", "3%", "3% to 12%", "Instant personal loan app from ?750 up to ?50,000 on your mobile!\n\n"));
            ammountarry.add(new Recyamount("PaySense", "Rs 1 Lakhs to 5 Lakhs", "12 to 60 Months", "2.5%", "2%", "Get personal loans in India from 5,000 to 5 lakh by PaySense Personal Loan App\n\n"));
            ammountarry.add(new Recyamount("Branch", "Rs 5 Lakhs to 50 Lakhs", "60 to 240 Months", "2%", "2%", "Branch is the simplest and most secure way to borrow, save, and improve your financial health all from the convenience of your phone. Branch Personal Finance app is operated by Branch International financial services which is an RBI registered NBFC. Branch is secure and regulated by all laws as dictated for NBFC by RBI making it 100% secure for users.\u00a0\n \n"));
        } else {

            ammountarry.add(new Recyamount("Vizzve", "Rs 10,000 to 1 Lakh", "3 month to 1 year", "2%", "0.50%", "Vizzve microseva instant loan app for student, salaried & pay per day loans\n\n"));
            ammountarry.add(new Recyamount("Navi", "1 Lakh to 5 Lakh", "12 month to 60 months", "2%", "2.99%", "Navi is a new age digital platform which provides you easy access to Instant Personal Loans upto Rs 5 lakhs and Home Loans upto Rs 1.5 crores in a seamless and transparent manner.\u00a0\n\n\n\n"));
            ammountarry.add(new Recyamount("KreditBee", "Rs 5 Lakh to 15 Lakh", "12 month to 120 months", "0% to 10.95% per annum", "1,250(2.5%)", "Personal Loan from ? 1000 to ? 2 Lakh for 62 days to 15 months at 0 - 2.49% p.m.\n\n"));
            ammountarry.add(new Recyamount("IDFC First Bank Loans", "Rs 20,000 to 40 Lakhs", "12 month to 60 months", "3%", "2%", "Instant Loans Online- Personal loans and app for all loan financing needs.\n \n\n"));
        }
        Amount_list.setAdapter(new adapter_rs(this, ammountarry));
    }

}