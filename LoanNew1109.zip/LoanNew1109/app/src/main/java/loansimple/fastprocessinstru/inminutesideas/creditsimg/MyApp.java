package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import android.app.Activity;
import android.app.Application;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.multidex.MultiDex;

import com.facebook.ads.Ad;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.kaopiz.kprogresshud.KProgressHUD;

import java.util.ArrayList;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAdMobAppOpenManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;


public class MyApp extends Application {
    public static SharedPreferences.Editor editor;
    public static SharedPreferences preferences;

    //ads
    private static MyApp instance = null;
    public static Point displaySize = new Point();
    public static String prefName = "myPref";
    public static int count_click_for_alt = -1;
    public static int count_native = -1;
    public static int count_banner = -1;
    public static InterstitialAd mInterstitialAd = null;
    public static com.facebook.ads.InterstitialAd fb_ins1 = null;

    public static CashonAdListner top_listner = null;
    private static ArrayList<String> interstitial_sequence;
    private static ArrayList<String> native_sequence;
    private static ArrayList<String> banner_sequence;
    ///
    public static void startAppOpen() {
        if (instance != null) {
            CashAdMobAppOpenManager adMobAppOpenManager;
            adMobAppOpenManager = new CashAdMobAppOpenManager(instance);
            adMobAppOpenManager.fetchAd();
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance=this;
        preferences = getSharedPreferences("get_extra", 0);
        editor = preferences.edit();
    }

    public static boolean getvaluepre(String Val, Boolean Defaultval) {

        boolean z = preferences.getBoolean(Val, Defaultval);
        return z;
    }

    public static void SetvalBool(String Val, Boolean Setvall) {
        editor.putBoolean(Val, Setvall);
        editor.commit();
    }

    public static String getvaluepre(String Val, String Defaultval) {

        String z = preferences.getString(Val, Defaultval);
        return z;
    }

    public static void SetvalString(String Val, String Setvall) {
        editor.putString(Val, Setvall);
        editor.commit();
    }

    public static int getvaluepre(String Val, int Defaultval) {

        int z = preferences.getInt(Val, Defaultval);
        return z;
    }

    public static void Setvalint(String Val, int Setvall) {
        editor.putInt(Val, Setvall);
        editor.commit();
    }
    public static void show_exit_dialog(Activity activity) {

        BottomSheetDialog dialog = new BottomSheetDialog(activity);


        View view = activity.getLayoutInflater().inflate(R.layout.exit_dialog, null);

        dialog.setContentView(view);

        TemplateView template = view.findViewById(R.id.my_template);
        template.setVisibility(View.INVISIBLE);
        if (CashAppManager.getInstance(activity).is_ad_status()) {

            String id_nativ = CashAppManager.getInstance(activity).get_amob_nativ_id();

            if (!id_nativ.equalsIgnoreCase("")) {

                AdLoader adLoader = new AdLoader.Builder(activity, id_nativ)
                        .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                            @Override
                            public void onNativeAdLoaded(NativeAd nativeAd) {
                                NativeTemplateStyle styles = new
                                        NativeTemplateStyle.Builder().build();
                                template.setVisibility(View.VISIBLE);
                                template.setStyles(styles);
                                template.setNativeAd(nativeAd);
                            }
                        })
                        .build();

                adLoader.loadAd(new AdRequest.Builder().build());
            }
        }

        TextView yes, no, rateus;

        yes = view.findViewById(R.id.yes);
        no = view.findViewById(R.id.no);
        rateus = view.findViewById(R.id.rateus);

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                Intent intent = new Intent("android.intent.action.MAIN");
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addCategory("android.intent.category.HOME");
                activity.startActivity(intent);
                activity.finishAffinity();
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();

            }
        });
        rateus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                try {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + activity.getPackageName())));
                } catch (ActivityNotFoundException e) {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + activity.getPackageName())));
                }

            }
        });
        dialog.show();

    }

    public static boolean is_dialog(Activity activity) {

        SharedPreferences preferences = activity.getSharedPreferences("get_extra", 0);
        SharedPreferences.Editor editor = preferences.edit();
        return preferences.getBoolean("is_dialog", true);
    }

    public static long dialog_sec(Activity activity) {

        SharedPreferences preferences = activity.getSharedPreferences("get_extra", 0);
        SharedPreferences.Editor editor = preferences.edit();
        return preferences.getInt("dialog_sec", 1000);
    }

    public static void load_adfb(Activity activity) {
        fb_ins1 = null;
        if (CashAppManager.getInstance(activity).is_ad_status_fb()) {
            com.facebook.ads.InterstitialAd interstitialAd_fb = new com.facebook.ads.InterstitialAd(activity, new CashAppManager(activity).get_fb_ins_id());
            InterstitialAdListener interstitialAdListener = new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                    Log.e("my_log", "onInterstitialDisplayed: ");
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    try {
                        top_listner.onsuccess();
                        top_listner = null;
                    } catch (Exception e) {

                    }

                    load_adfb(activity);
                    Log.e("my_log", "onInterstitialDismissed: ");
                }

                @Override
                public void onError(Ad ad, com.facebook.ads.AdError adError) {
                    fb_ins1 = null;
                    Log.e("my_log", "onError: " + adError.getErrorMessage());
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    fb_ins1 = interstitialAd_fb;
                    Log.e("my_log", "onAdLoaded: ");
                }

                @Override
                public void onAdClicked(Ad ad) {
                    Log.e("my_log", "onAdClicked: ");
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                    Log.e("my_log", "onLoggingImpression: ");
                }
            };

            interstitialAd_fb.loadAd(
                    interstitialAd_fb.buildLoadAdConfig()
                            .withAdListener(interstitialAdListener)
                            .build());
        }
    }

    public static void load_ad(Activity context) {
        if (CashAppManager.getInstance(context).is_ad_status_Admob()) {
            String id_ins = CashAppManager.getInstance(context).get_amob_ins_id();

            if (!id_ins.equalsIgnoreCase("")) {
                mInterstitialAd = null;

                AdRequest adRequest = new AdRequest.Builder().build();

                InterstitialAd.load(context, id_ins, adRequest,
                        new InterstitialAdLoadCallback() {
                            @Override
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                mInterstitialAd = interstitialAd;
                            }

                            @Override
                            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                                mInterstitialAd = null;
                            }
                        });


            } else {
                mInterstitialAd = null;
            }
        }

    }

    public static void show_ad(Activity context, CashonAdListner listner) {
        SharedPreferences preferences = context.getSharedPreferences("click_pref", 0);
        SharedPreferences.Editor editor = preferences.edit();

        SharedPreferences mysharedpreferences = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);

        if (CashAppManager.getInstance(context).is_ad_status()) {
            if (preferences.getInt("ins_click", 1) >= CashAppManager.getInstance(context).get_mailclcik_count()) {
                editor.putInt("ins_click", 1).apply();

                count_click_for_alt++;

                int app_howShowAd = mysharedpreferences.getInt("howShowAd", 0);
                String adPlatformSequence = mysharedpreferences.getString("adPlatformSequence", "");
                String alernateAdShow = mysharedpreferences.getString("adPlatformSequence", "");

                interstitial_sequence = new ArrayList<String>();
                if (app_howShowAd == 0 && !adPlatformSequence.isEmpty()) {
                    String adSequence[] = adPlatformSequence.split(",");
                    for (int i = 0; i < adSequence.length; i++) {
                        interstitial_sequence.add(adSequence[i]);
                    }
                    ArrayList<String> interstitial_sequencenew = new ArrayList<String>();
                    for (int a = 0; a < interstitial_sequence.size(); a++) {
                        if (interstitial_sequence.get(a).equalsIgnoreCase("StartApp") || interstitial_sequence.get(a).equalsIgnoreCase("Link_Ad")) {

                        } else {
                            interstitial_sequencenew.add(interstitial_sequence.get(a));
                        }
                    }


                    if (interstitial_sequence.size() != 0) {
                        showInterstitialAd(interstitial_sequencenew.get(0), context, listner);
                    }


                } else if (app_howShowAd == 1 && !alernateAdShow.isEmpty()) {
                    String alernateAd[] = alernateAdShow.split(",");

                    int index = 0;
                    for (int j = 0; j <= 10; j++) {
                        if (count_click_for_alt % alernateAd.length == j) {
                            index = j;
                            interstitial_sequence.add(alernateAd[index]);
                        }
                    }
                    String adSequence[] = adPlatformSequence.split(",");
                    for (int j = 0; j < adSequence.length; j++) {
                        if (interstitial_sequence.size() != 0) {
                            if (!interstitial_sequence.get(0).equals(adSequence[j])) {
                                interstitial_sequence.add(adSequence[j]);
                            }
                        }

                    }

                    ArrayList<String> interstitial_sequencenew = new ArrayList<String>();
                    for (int a = 0; a < interstitial_sequence.size(); a++) {
                        if (interstitial_sequence.get(a).equalsIgnoreCase("StartApp") || interstitial_sequence.get(a).equalsIgnoreCase("Link_Ad")) {

                        } else {
                            interstitial_sequencenew.add(interstitial_sequence.get(a));
                        }
                    }


                    if (interstitial_sequence.size() != 0) {
                        showInterstitialAd(interstitial_sequencenew.get(0), context, listner);
                    }


                } else {
                    int click_old = preferences.getInt("ins_click", 1);
                    int click_new = click_old + 1;
                    Log.e("my_log", "show_ad: " + click_new);
                    editor.putInt("ins_click", click_new).apply();
                    listner.onsuccess();
                }


            } else {
                int click_old = preferences.getInt("ins_click", 1);
                int click_new = click_old + 1;
                Log.e("my_log", "show_ad: " + click_new);
                editor.putInt("ins_click", click_new).apply();
                listner.onsuccess();
            }
        } else {
            int click_old = preferences.getInt("ins_click", 1);
            int click_new = click_old + 1;
            Log.e("my_log", "show_ad: " + click_new);
            editor.putInt("ins_click", click_new).apply();
            listner.onsuccess();
        }

    }

    public static String nativeAd(Activity context) {
        String nativdata = nativstring(context);
        return nativdata;


    }
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }
    public static String nativstring(Activity context) {
        SharedPreferences mysharedpreferences = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);

        if (CashAppManager.getInstance(context).is_ad_status()) {


            int app_howShowAd = mysharedpreferences.getInt("howShowAd", 0);
            String adPlatformSequence = mysharedpreferences.getString("adPlatformSequence", "");
            String alernateAdShow = mysharedpreferences.getString("adPlatformSequence", "");

            count_native++;
            native_sequence = new ArrayList<String>();
            if (app_howShowAd == 0 && !adPlatformSequence.isEmpty()) {
                String adSequence[] = adPlatformSequence.split(",");
                for (int i = 0; i < adSequence.length; i++) {
                    native_sequence.add(adSequence[i]);
                }

            } else if (app_howShowAd == 1 && !alernateAdShow.isEmpty()) {
                String alernateAd[] = alernateAdShow.split(",");

                int index = 0;
                for (int j = 0; j <= 10; j++) {
                    if (count_native % alernateAd.length == j) {
                        index = j;
                        native_sequence.add(alernateAd[index]);
                    }
                }

                String adSequence[] = adPlatformSequence.split(",");
                for (int j = 0; j < adSequence.length; j++) {
                    if (native_sequence.size() != 0) {
                        if (!native_sequence.get(0).equals(adSequence[j])) {
                            native_sequence.add(adSequence[j]);
                        }
                    }
                }
            }

            ArrayList<String> native_sequenceenew = new ArrayList<String>();
            for (int a = 0; a < native_sequence.size(); a++) {
                if (native_sequence.get(a).equalsIgnoreCase("StartApp") || native_sequence.get(a).equalsIgnoreCase("Link_Ad")) {

                } else {

                    native_sequenceenew.add(native_sequence.get(a));
                }
            }


            if (native_sequence.size() != 0) {
                Log.e("my_log native", "nativeAd: " + native_sequenceenew.get(0));
                return native_sequenceenew.get(0);
            } else {
                Log.e("my_log native", "nativeAd: ");
                return "";
            }

        } else {
            return "";
        }
    }

    public static String bannerAd(Activity context) {

        SharedPreferences mysharedpreferences = context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);

        if (CashAppManager.getInstance(context).is_ad_status()) {


            int app_howShowAd = mysharedpreferences.getInt("howShowAd", 0);
            String adPlatformSequence = mysharedpreferences.getString("adPlatformSequence", "");
            String alernateAdShow = mysharedpreferences.getString("adPlatformSequence", "");

            count_banner++;
            banner_sequence = new ArrayList<String>();
            if (app_howShowAd == 0 && !adPlatformSequence.isEmpty()) {
                String adSequence[] = adPlatformSequence.split(",");
                for (int i = 0; i < adSequence.length; i++) {
                    banner_sequence.add(adSequence[i]);
                }

            } else if (app_howShowAd == 1 && !alernateAdShow.isEmpty()) {
                String alernateAd[] = alernateAdShow.split(",");

                int index = 0;
                for (int j = 0; j <= 10; j++) {
                    if (count_banner % alernateAd.length == j) {
                        index = j;
                        banner_sequence.add(alernateAd[index]);
                    }
                }

                String adSequence[] = adPlatformSequence.split(",");
                for (int j = 0; j < adSequence.length; j++) {
                    if (banner_sequence.size() != 0) {
                        if (!banner_sequence.get(0).equals(adSequence[j])) {
                            banner_sequence.add(adSequence[j]);
                        }
                    }
                }
            }

            ArrayList<String> banner_sequenceenew = new ArrayList<String>();
            for (int a = 0; a < banner_sequence.size(); a++) {
                if (banner_sequence.get(a).equalsIgnoreCase("StartApp") || banner_sequence.get(a).equalsIgnoreCase("Link_Ad")) {

                } else {
                    banner_sequenceenew.add(banner_sequence.get(a));
                }
            }


            if (banner_sequence.size() != 0) {
                return banner_sequenceenew.get(0);
            } else {
                return "";
            }

        } else {
            return "";
        }

    }


    private static void showInterstitialAd(String platform, Activity context, CashonAdListner listner) {


        if (platform.equals("Admob")) {


            if (MyApp.is_dialog(context)) {

                KProgressHUD kud = KProgressHUD.create(context)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel("Ads Loading...")
                        .setCancellable(false)
                        .setAnimationSpeed(2)
                        .setDimAmount(0.5f)
                        .show();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        kud.dismiss();

                        if (mInterstitialAd == null) {
                            load_ad(context);
                            nextInterstitialPlatform(context, listner);
                        } else {
                            mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override
                                public void onAdClicked() {
                                    super.onAdClicked();
                                }

                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    super.onAdDismissedFullScreenContent();
                                    load_ad(context);
                                    listner.onsuccess();
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                    super.onAdFailedToShowFullScreenContent(adError);
                                    load_ad(context);
                                    listner.onsuccess();
                                }

                                @Override
                                public void onAdImpression() {
                                    super.onAdImpression();
                                }

                                @Override
                                public void onAdShowedFullScreenContent() {
                                    super.onAdShowedFullScreenContent();
                                }
                            });
                            mInterstitialAd.show(context);

                        }
                    }
                }, MyApp.dialog_sec(context));
            } else {
                if (mInterstitialAd == null) {
                    load_ad(context);
                    nextInterstitialPlatform(context, listner);
                } else {
                    mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdClicked() {
                            super.onAdClicked();
                        }

                        @Override
                        public void onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent();
                            load_ad(context);
                            listner.onsuccess();
                        }

                        @Override
                        public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                            super.onAdFailedToShowFullScreenContent(adError);
                            load_ad(context);
                            listner.onsuccess();
                        }

                        @Override
                        public void onAdImpression() {
                            super.onAdImpression();
                        }

                        @Override
                        public void onAdShowedFullScreenContent() {
                            super.onAdShowedFullScreenContent();
                        }
                    });
                    mInterstitialAd.show(context);

                }
            }

        } else if (platform.equals("Facebook")) {
            if (fb_ins1 == null) {
                nextInterstitialPlatform(context, listner);
                load_adfb(context);
                top_listner = null;
            } else {
                top_listner = listner;
                if (MyApp.is_dialog(context)) {
                    KProgressHUD kud = KProgressHUD.create(context)
                            .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                            .setLabel("Ads Loading...")
                            .setCancellable(false)
                            .setAnimationSpeed(2)
                            .setDimAmount(0.5f)
                            .show();

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            kud.dismiss();

                            if (fb_ins1 == null) {
                                load_adfb(context);
                                nextInterstitialPlatform(context, listner);
                            } else {
                                fb_ins1.show();

                            }
                        }
                    }, MyApp.dialog_sec(context));
                } else {
                    if (fb_ins1 == null) {
                        load_adfb(context);
                        nextInterstitialPlatform(context, listner);
                    } else {
                        fb_ins1.show();

                    }
                }
            }


        } else {
            listner.onsuccess();
            nextInterstitialPlatform(context, listner);
        }

    }

    public static void nextInterstitialPlatform(Activity context, CashonAdListner listner) {

        if (interstitial_sequence.size() != 0) {
            interstitial_sequence.remove(0);

            if (interstitial_sequence.size() != 0) {
                showInterstitialAd(interstitial_sequence.get(0), context, listner);
            } else {
                listner.onsuccess();
            }

        } else {
            listner.onsuccess();

        }
    }
}
