package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import static loansimple.fastprocessinstru.inminutesideas.creditsimg.MyApp.getvaluepre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;

import java.util.Locale;

public class BaseActivity_Lang extends AppCompatActivity {
    public void setApplicationLocale(String str) {
        Locale locale = new Locale(str);
        Resources resources = getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        configuration.setLayoutDirection(locale);
        configuration.locale = locale;
        resources.updateConfiguration(configuration, displayMetrics);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setApplicationLocale(getvaluepre("lang_code", "en"));
    }
}