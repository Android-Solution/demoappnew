package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class Policy_act_loan extends AppCompatActivity {
    WebView webview_policy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy_act_loan);
        webview_policy = findViewById(R.id.webview_policy);
        webview_policy.loadUrl("file:///android_asset/policyy.html");
    }

    @Override
    public void onBackPressed() {
        MyApp.show_ad(Policy_act_loan.this, new CashonAdListner() {
            @Override
            public void onsuccess() {
                Policy_act_loan.super.onBackPressed();

            }
        });
    }

}