package loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class Cashdream_AppOpen extends AppCompatActivity {
    private Activity MyApplication;
    private Activity currentActivity;
    private AppOpenAd appOpenAd = null;

    private AppOpenAd.AppOpenAdLoadCallback loadCallback;
    //    private Dialog pd;
    splshADlistner splshADlistner;


    public interface splshADlistner {
        void onsuccess();
    }

    Runnable runnable;
    Handler handler;

    boolean loading = true;
    splshADlistner listnermy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyApplication = Cashdream_AppOpen.this;

        runnable = new Runnable() {
            @Override
            public void run() {
                if (loading) {
                    loading = false;
                    try {
                        listnermy.onsuccess();
                    } catch (Exception e) {

                    }

                }
            }
        };
        handler = new Handler();

        handler.postDelayed(runnable, 10000);


    }


    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }

    public void fetchAd(final splshADlistner listner) {
        listnermy = listner;
        splshADlistner = listner;
        loadCallback =
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull AppOpenAd ad) {
                        super.onAdLoaded(ad);
                        appOpenAd = ad;
                        if (loading) {
                            loading = false;
                            FullScreenContentCallback fullScreenContentCallback =
                                    new FullScreenContentCallback() {
                                        @Override
                                        public void onAdDismissedFullScreenContent() {
                                            try{
                                                handler.removeCallbacks(runnable);
                                            }catch (Exception e){

                                            }
                                            listner.onsuccess();
                                        }

                                        @Override
                                        public void onAdFailedToShowFullScreenContent(AdError adError) {
//                                        pd.dismiss();
                                            try{
                                                handler.removeCallbacks(runnable);
                                            }catch (Exception e){

                                            }
                                            listner.onsuccess();
                                        }

                                        @Override
                                        public void onAdShowedFullScreenContent() {
//                                        pd.dismiss();

                                        }
                                    };

                            appOpenAd.show(currentActivity);
                            appOpenAd.setFullScreenContentCallback(fullScreenContentCallback);
                        }
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        super.onAdFailedToLoad(loadAdError);
//                        pd.dismiss();
                        listner.onsuccess();
                        try{
                            handler.removeCallbacks(runnable);
                        }catch (Exception e){

                        }
                    }

                };
        SharedPreferences preferences = getSharedPreferences("which_open", 0);
        SharedPreferences.Editor editor = preferences.edit();

        if (CashAppManager.getInstance(Cashdream_AppOpen.this).is_appopen_avilable()) {
            adx_ad();
        } else {
            listner.onsuccess();
            try{
                handler.removeCallbacks(runnable);
            }catch (Exception e){

            }

        }

    }

    public void adx_ad() {
        MobileAds.initialize(
                this,
                new OnInitializationCompleteListener() {
                    @Override
                    public void onInitializationComplete(InitializationStatus initializationStatus) {
                        AdRequest request = getAdRequest();
                        AppOpenAd.load(
                                MyApplication, CashAppManager.getInstance(Cashdream_AppOpen.this).get_amob_appopen_id(), request,
                                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT, loadCallback);
                    }
                });

    }




    @Override
    protected void onResume() {
        super.onResume();
        currentActivity = Cashdream_AppOpen.this;


    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        currentActivity = null;
        try{
            handler.removeCallbacks(runnable);
        }catch (Exception e){

        }
    }

}