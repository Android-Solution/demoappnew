package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.Cashdream_AppOpen;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashgetDataListner;

public class SplashPage extends Cashdream_AppOpen {
    public static final String MyPREFERENCES = "MyPrefs";
    private static SplashPage mInstance;
    SharedPreferences.Editor editor;
    boolean isFirstTime = true;

    SharedPreferences sharedPreferences;
    boolean is_retry;
    private Runnable network_runnable;
    private Handler network_refreshHandler;

    private SharedPreferences mysharedpreferences;
    LinearLayout retry_view;
    TextView retry_buttton;
    private boolean isNetworkAvailable() {
        ConnectivityManager manager =
                (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        boolean isAvailable = false;
        if (networkInfo != null && networkInfo.isConnected()) {
            // Network is present and connected
            isAvailable = true;
        }
        return isAvailable;
    }
    public void gotoHome() {

            Intent intent = new Intent(this, LoanAppLanguagePage.class);
            startActivity(intent);
            finish();

    }
    public void ADSinit(final Activity activity, final int vcode, final ViewGroup retry_view, final TextView retry_text) {
        if (!isNetworkAvailable()) {
            is_retry = false;
            retry_view.setVisibility(View.VISIBLE);
        }

        retry_view.setVisibility(View.GONE);
        network_refreshHandler = new Handler();
        network_runnable = new Runnable() {
            @Override
            public void run() {
                if (isNetworkAvailable()) {
                    is_retry = true;
                    retry_text.setText("Retry");
                } else {
                    retry_view.setVisibility(View.VISIBLE);
                    is_retry = false;
                    retry_text.setText("Please Connect To Internet");
                }
                network_refreshHandler.postDelayed(this, 1000);
            }
        };
        network_refreshHandler.postDelayed(network_runnable, 1000);

        retry_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (is_retry) {
                    startActivity(new Intent(SplashPage.this, SplashPage.class));
                } else {
                    startActivityForResult(new Intent(android.provider.Settings.ACTION_SETTINGS), 0);
                }
            }
        });


        mysharedpreferences = activity.getSharedPreferences(activity.getPackageName(), MODE_PRIVATE);


        Calendar calender = Calendar.getInstance();
        calender.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.US);
        String currentDate = df.format(calender.getTime());


        int appDownload;
        String status = mysharedpreferences.getString("firsttime", "true");
        SharedPreferences.Editor editor = mysharedpreferences.edit();
        if (status.equals("true")) {
            editor.putString("date", currentDate).apply();
            editor.putString("firsttime", "false").apply();
            appDownload = 1;


        } else {
            String date = mysharedpreferences.getString("date", "");
            if (!currentDate.equals(date)) {
                editor.putString("date", currentDate).apply();
                appDownload = 2;
            } else {
                appDownload = 3;
            }

        }

        String ads_url = "https://encoded-work.com/api/getapdata/packagename/apikey/download?packagename=";
        ads_url = ads_url + activity.getPackageName();
        ads_url = ads_url + "&apikey=" + getKeyHash(activity);


        ads_url = ads_url + "&appDownload=" + appDownload;

        ads_url = ads_url + "&time=" + System.currentTimeMillis();

        RequestQueue requestQueue = Volley.newRequestQueue(activity);
        StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET, ads_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response_txt) {

                try {
                    JSONArray response_array = new JSONArray(response_txt);

                    JSONObject response = response_array.getJSONObject(0);

                    boolean status = response.getBoolean("STATUS");

                    if (status) {
                        SharedPreferences.Editor editor1 = mysharedpreferences.edit();
                        editor1.putString("response", response.toString());
                        editor1.apply();

                        CashAppManager.getInstance(activity).getResponseFromPref(new CashgetDataListner() {
                            @Override
                            public void onsuccess() {
                                MyApp.startAppOpen();
                                fetchAd(new splshADlistner() {
                                    @Override
                                    public void onsuccess() {

                                        gotoHome();
                                    }
                                });

                            }

                            @Override
                            public void onUpdate(String url) {
                                update(url);
                            }

                            @Override
                            public void onRedirect(String url) {
                                redirect(url);
                            }

                            @Override
                            public void reloadActivity() {

                            }

                            @Override
                            public void ongetExtradata(JSONObject extraData) {
                                Log.e("extra", extraData.toString());
                                SharedPreferences preferences = getSharedPreferences("get_extra", 0);
                                SharedPreferences.Editor editor = preferences.edit();

                                try {
                                    if (extraData.getString("startnewapp").equalsIgnoreCase("false")) {
                                        editor.putBoolean("startnewapp", false).apply();
                                    } else {
                                        editor.putBoolean("startnewapp", true).apply();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                try {
                                    if (extraData.getString("status").equalsIgnoreCase("false")) {
                                        editor.putBoolean("status", false).apply();
                                    } else {
                                        editor.putBoolean("status", true).apply();
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                                try {
                                    if (extraData.getString("is_dialog").equalsIgnoreCase("false")) {
                                        editor.putBoolean("is_dialog", false).apply();
                                    } else {
                                        editor.putBoolean("is_dialog", true).apply();
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                try {
                                    editor.putInt("dialog_sec", Integer.parseInt(extraData.getString("dialog_sec"))).apply();
                                } catch (JSONException e) {
                                    editor.putInt("dialog_sec", 1000).apply();
                                }
                            }

                            @Override
                            public void ongetMoreApp(JSONArray moreApp) {

                            }
                        }, vcode);
                    }


                } catch (Exception e) {
                    Log.e("my_log", "onResponse: " + e.getMessage());
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
        requestQueue.add(jsonObjectRequest);
    }

    void redirect(final String url) {

        final Dialog dialog = new Dialog(SplashPage.this);
        dialog.setCancelable(false);
        View view = getLayoutInflater().inflate(R.layout.updatedialog, null);
        dialog.setContentView(view);
        TextView update;
        update = view.findViewById(R.id.update);


        TextView update_text_en = view.findViewById(R.id.update_text_en);
        TextView update_text_hi = view.findViewById(R.id.update_text_hi);

        update_text_en.setText(getResources().getString(R.string.installnewappdesc_en));
        update_text_hi.setText(getResources().getString(R.string.installnewappdesc_hi));


        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("my_log", "onResponse: " + url);
                try {
                    Uri marketUri = Uri.parse(url);
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                    startActivity(marketIntent);
                } catch (Exception ignored) {
                    try {
                        Uri marketUri = Uri.parse(url);
                        Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                        startActivity(marketIntent);
                    } catch (ActivityNotFoundException ignored1) {
                    }
                }
            }
        });

        dialog.create();

        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

    }

    void update(final String url) {


        final Dialog dialog = new Dialog(SplashPage.this);
        dialog.setCancelable(false);
        View view = LayoutInflater.from(SplashPage.this).inflate(R.layout.updatedialog, null);
        dialog.setContentView(view);
        TextView update;
        update = view.findViewById(R.id.update);

        TextView update_text_en = view.findViewById(R.id.update_text_en);
        TextView update_text_hi = view.findViewById(R.id.update_text_hi);

        TextView title_en = view.findViewById(R.id.title_en);
        TextView title_hi = view.findViewById(R.id.title_hi);

        title_en.setVisibility(View.GONE);
        title_hi.setVisibility(View.GONE);


        update_text_en.setText("Please update the " + getResources().getString(R.string.app_name) + " , Do not miss latest Features.");
        update_text_hi.setText("कृपया " + getResources().getString(R.string.app_name) + " को अपडेट करें नवीनतम सुविधाओं को न चूकें");


        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    Log.e("my_log", "onResponse: " + url);
                    Uri marketUri = Uri.parse(url);
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                    startActivity(marketIntent);
                } catch (ActivityNotFoundException ignored) {
                }
            }
        });

        dialog.create();
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }
    private String getKeyHash(Activity activity) {
        PackageInfo info;
        try {
            info = activity.getPackageManager().getPackageInfo(activity.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md;
                md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String something = (Base64.encodeToString(md.digest(), Base64.NO_WRAP));
                return something.replace("+", "*");
            }
        } catch (PackageManager.NameNotFoundException e1) {
            e1.printStackTrace();

        } catch (NoSuchAlgorithmException e) {

        } catch (Exception e) {

        }
        return null;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_page);
        mInstance = this;
        retry_view = findViewById(R.id.retry_view);
        retry_buttton = findViewById(R.id.retry_buttton);
        ADSinit(SplashPage.this, BuildConfig.VERSION_CODE, retry_view, retry_buttton);

    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}