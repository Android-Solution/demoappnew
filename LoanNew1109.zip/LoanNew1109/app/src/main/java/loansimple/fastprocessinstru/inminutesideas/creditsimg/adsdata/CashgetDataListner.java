package loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata;

import org.json.JSONArray;
import org.json.JSONObject;

public interface CashgetDataListner {

    void onsuccess();

    void onUpdate(String url);

    void onRedirect(String url);

    void reloadActivity();

    void ongetExtradata(JSONObject extraData);

    void ongetMoreApp(JSONArray moreApp);
}
