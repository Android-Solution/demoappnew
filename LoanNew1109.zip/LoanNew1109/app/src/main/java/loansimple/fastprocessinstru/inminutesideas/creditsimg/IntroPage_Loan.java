package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.nativead.NativeAd;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.Cashinflatefb;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class IntroPage_Loan extends BaseActivity_Lang {
    public void backkk(View view) {
        Log.e("dd", "");

        onBackPressed();


    }
    @Override
    public void onBackPressed() {
        MyApp.show_ad(IntroPage_Loan.this, new CashonAdListner() {
            @Override
            public void onsuccess() {
                IntroPage_Loan.super.onBackPressed();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro_page_loan);
        String bb = MyApp.nativeAd(IntroPage_Loan.this);
        if (bb.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(IntroPage_Loan.this).is_ad_status()) {
                String id_banner = CashAppManager.getInstance(IntroPage_Loan.this).get_amob_banner_id();

                if (!id_banner.equalsIgnoreCase("")) {
                    AdView adView = new AdView(this);
                    adView.setAdSize(AdSize.BANNER);
                    adView.setAdUnitId(id_banner);
                    LinearLayout succes_banner = findViewById(R.id.succes_banner);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                    succes_banner.addView(adView);
                }
            }
        } else if (bb.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(IntroPage_Loan.this).is_ad_status_fb()) {
                LinearLayout succes_banner = findViewById(R.id.succes_banner);
                String id_banner = CashAppManager.getInstance(IntroPage_Loan.this).get_fb_banner_id();
                com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, id_banner, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                succes_banner.addView(adView);
                adView.loadAd();
            }
        }
        ///end

        //Nativee
        String aa = MyApp.nativeAd(IntroPage_Loan.this);
        TemplateView template = findViewById(R.id.my_template_success);
        template.setVisibility(View.INVISIBLE);
        if (aa.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(IntroPage_Loan.this).is_ad_status_Admob()) {

                String id_nativ = CashAppManager.getInstance(IntroPage_Loan.this).get_amob_nativ_id();

                if (!id_nativ.equalsIgnoreCase("")) {

                    AdLoader adLoader = new AdLoader.Builder(this, id_nativ)
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(NativeAd nativeAd) {
                                    template.setVisibility(View.VISIBLE);
                                    NativeTemplateStyle styles = new
                                            NativeTemplateStyle.Builder().build();

                                    template.setStyles(styles);
                                    template.setNativeAd(nativeAd);
                                }
                            })
                            .build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
        } else if (aa.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(IntroPage_Loan.this).is_ad_status_fb()) {
                template.removeAllViews();

                com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(this, CashAppManager.getInstance(IntroPage_Loan.this).get_amob_facebook_id());

                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        new Cashinflatefb().inflatefb(nativeAd, template, IntroPage_Loan.this);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                // Request an ad
                nativeAd.loadAd(
                        nativeAd.buildLoadAdConfig()
                                .withAdListener(nativeAdListener)
                                .build());


            }
        }

        (findViewById(R.id.sharee)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
                intent.putExtra("android.intent.extra.TEXT", "*Your pre approved loan of rs. 3,00,000/-* download this app and get it now." + "\n\nhttps://play.google.com/store/apps/details?id=" + getPackageName());
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "Share"));
            }
        });
        (findViewById(R.id.policyy)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(IntroPage_Loan.this,Policy_act_loan.class));
            }
        });
        (findViewById(R.id.formm)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApp.show_ad(IntroPage_Loan.this, new CashonAdListner() {
                    @Override
                    public void onsuccess() {
                        startActivity(new Intent(IntroPage_Loan.this,FillFormfirstintro_loan.class));
                    }});

            }
        });
        (findViewById(R.id.startt)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApp.show_ad(IntroPage_Loan.this, new CashonAdListner() {
                    @Override
                    public void onsuccess() {
                        startActivity(new Intent(IntroPage_Loan.this,Loanprocesslistloans.class));
                    }});

            }
        });
        (findViewById(R.id.ratee)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                 startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" +getPackageName())));
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                }
            }
        });
    }
}