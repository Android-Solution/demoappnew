package loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata;

public interface CashonAdListner {

    void onsuccess();

}
