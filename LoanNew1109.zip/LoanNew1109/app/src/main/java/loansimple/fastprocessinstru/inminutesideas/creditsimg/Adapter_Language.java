package loansimple.fastprocessinstru.inminutesideas.creditsimg;


import static loansimple.fastprocessinstru.inminutesideas.creditsimg.MyApp.SetvalString;
import static loansimple.fastprocessinstru.inminutesideas.creditsimg.MyApp.getvaluepre;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;

public class Adapter_Language extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int UNIFIED_NATIVE_AD_LOAD_TYPE = 3;
    private static final int UNIFIED_NATIVE_AD_VIEW_TYPE = 1;
    ArrayList<Model_Language> LanguageList1;
    LoanAppLanguagePage languageActivity1;

    String text;

    public Adapter_Language(LoanAppLanguagePage languageActivity2, String str, ArrayList<Model_Language> arrayList) {
        this.languageActivity1 = languageActivity2;
        this.LanguageList1 = arrayList;
        this.text = str;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        return new ViewHolder(LayoutInflater.from(this.languageActivity1).inflate(R.layout.item_langage, viewGroup, false));

    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, final int i) {
        int itemViewType = getItemViewType(i);
        if (itemViewType != 1) {
            if (itemViewType != 3) {
                ViewHolder viewHolder2 = (ViewHolder) viewHolder;
                final Model_Language languageModel = (Model_Language) this.LanguageList1.get(i);
                viewHolder2.txt_language.setText(languageModel.getLanguage_name());
                viewHolder2.img_flag.setImageResource(languageModel.getFlag_image());
                if (this.text.equalsIgnoreCase(languageModel.getLanguage_code())) {

                    viewHolder2.main_rl.setBackgroundResource(R.drawable.btn_lang_selct);
                } else {
                    viewHolder2.main_rl.setBackgroundResource(R.drawable.btn_lang_unselct);

                }
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        Adapter_Language.this.text = languageModel.getLanguage_code();
                        SetvalString("lang_code", Adapter_Language.this.text);
                        Adapter_Language.this.notifyDataSetChanged();
                    }
                });
            }

        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.LanguageList1.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView check;
        ImageView img_flag;
        LinearLayout main_rl;
        TextView txt_language;

        public ViewHolder(View view) {
            super(view);
            this.txt_language = (TextView) view.findViewById(R.id.txt_language);
            this.img_flag = (ImageView) view.findViewById(R.id.img_flag);
//            this.check = (ImageView) view.findViewById(R.id.check);
            this.main_rl = (LinearLayout) view.findViewById(R.id.main_rl);
        }
    }


}

