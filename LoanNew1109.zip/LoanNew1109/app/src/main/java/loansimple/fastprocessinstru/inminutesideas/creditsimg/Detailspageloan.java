package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import static loansimple.fastprocessinstru.inminutesideas.creditsimg.NextFirstPage.createInstanceOfClass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.nativead.NativeAd;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.Cashinflatefb;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class Detailspageloan extends BaseActivity_Lang {
    TextView details_tvMaxAmount, details_tvTenure, details_tvProcessingFee, details_tvMonthlyInterest, details_tvLoanTerm;
    public void backkk(View view) {
        Log.e("dd", "");

        onBackPressed();


    }
    @Override
    public void onBackPressed() {
        MyApp.show_ad(Detailspageloan.this, new CashonAdListner() {
            @Override
            public void onsuccess() {
                Detailspageloan.super.onBackPressed();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailspageloan);
        String bb = MyApp.nativeAd(Detailspageloan.this);

        if (bb.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(Detailspageloan.this).is_ad_status()) {
                String id_banner = CashAppManager.getInstance(Detailspageloan.this).get_amob_banner_id();

                if (!id_banner.equalsIgnoreCase("")) {
                    AdView adView = new AdView(this);
                    adView.setAdSize(AdSize.BANNER);
                    adView.setAdUnitId(id_banner);
                    LinearLayout succes_banner = findViewById(R.id.succes_banner);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                    succes_banner.addView(adView);
                }
            }
        } else if (bb.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(Detailspageloan.this).is_ad_status_fb()) {
                LinearLayout succes_banner = findViewById(R.id.succes_banner);
                String id_banner = CashAppManager.getInstance(Detailspageloan.this).get_fb_banner_id();
                com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, id_banner, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                succes_banner.addView(adView);
                adView.loadAd();
            }
        }
        ///end

        //Nativee
        String aa = MyApp.nativeAd(Detailspageloan.this);
        TemplateView template = findViewById(R.id.my_template_success);
        template.setVisibility(View.INVISIBLE);
        if (aa.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(Detailspageloan.this).is_ad_status_Admob()) {

                String id_nativ = CashAppManager.getInstance(Detailspageloan.this).get_amob_nativ_id();

                if (!id_nativ.equalsIgnoreCase("")) {

                    AdLoader adLoader = new AdLoader.Builder(this, id_nativ)
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(NativeAd nativeAd) {
                                    template.setVisibility(View.VISIBLE);
                                    NativeTemplateStyle styles = new
                                            NativeTemplateStyle.Builder().build();

                                    template.setStyles(styles);
                                    template.setNativeAd(nativeAd);
                                }
                            })
                            .build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
        } else if (aa.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(Detailspageloan.this).is_ad_status_fb()) {
                template.removeAllViews();

                com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(this, CashAppManager.getInstance(Detailspageloan.this).get_amob_facebook_id());

                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        new Cashinflatefb().inflatefb(nativeAd, template, Detailspageloan.this);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                // Request an ad
                nativeAd.loadAd(
                        nativeAd.buildLoadAdConfig()
                                .withAdListener(nativeAdListener)
                                .build());


            }
        }

        ///


        this.details_tvMaxAmount = (TextView) findViewById(R.id.details_tvMaxAmount);
        this.details_tvTenure = (TextView) findViewById(R.id.details_tvTenure);
        this.details_tvProcessingFee = (TextView) findViewById(R.id.details_tvProcessingFee);
        this.details_tvMonthlyInterest = (TextView) findViewById(R.id.details_tvMonthlyInterest);
        this.details_tvLoanTerm = (TextView) findViewById(R.id.details_tvLoanTerm);
        Recyamount aVar2 = (Recyamount) getIntent().getSerializableExtra("recmodel");
        this.details_tvMaxAmount.setText(aVar2.amount);
        this.details_tvTenure.setText(aVar2.Period);
        this.details_tvLoanTerm.setText(aVar2.info);
        this.details_tvMonthlyInterest.setText(aVar2.rate);
        this.details_tvProcessingFee.setText(aVar2.percentage);

        (findViewById(R.id.btnDownloadApply)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Detailspageloan.this.getSharedPreferences("prefff", 0).getString("statusloan", "lost").equals("active")) {
                    try {
                        createInstanceOfClass(Detailspageloan.this, success_tokengen_loan.class);
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (InstantiationException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }

                } else {
                    try {
                        createInstanceOfClass(Detailspageloan.this, ooptryfoemfill.class);
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (InstantiationException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }

                }
            }
        });


    }
}