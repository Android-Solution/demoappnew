package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import java.io.Serializable;

public class Recyamount  implements Serializable {
    String Title;
    String amount;
    String Period;
    String percentage;
    String rate;
    String info;

    public Recyamount(String title, String amount, String period, String percentage, String rate, String info) {
        Title = title;
        this.amount = amount;
        Period = period;
        this.percentage = percentage;
        this.rate = rate;
        this.info = info;
    }
}
