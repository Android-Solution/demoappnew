package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.ArrayList;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class adapter_rs extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    Context context;
    ArrayList<Recyamount> arrayList1;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public Button Apply;
        LinearLayout valuee;
        public TextView Amount;


        public MyViewHolder(View view) {
            super(view);
            this.Amount = (TextView) view.findViewById(R.id.Amount);
            this.Apply = (Button) view.findViewById(R.id.btnApply);
            this.valuee = (LinearLayout) view.findViewById(R.id.valuee);
        }
    }

    public adapter_rs(Context context, ArrayList<Recyamount> arrayList1) {
        this.context = context;
        this.arrayList1 = arrayList1;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(this.context).inflate(R.layout.amount_recycler, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MyViewHolder holder1 = (MyViewHolder) holder;
        ArrayList<Recyamount> arrayList = this.arrayList1;
        holder1.Amount.setText(arrayList.get(position).amount);
    Recyamount arrayList2 = new Recyamount(arrayList.get(position).Title,
        arrayList.get(position).amount,
        arrayList.get(position).Period,
        arrayList.get(position).percentage,
        arrayList.get(position).rate,
        arrayList.get(position).info);

        holder1.valuee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApp.show_ad((Activity) context, new CashonAdListner() {
                    @Override
                    public void onsuccess() {
                        context.startActivity(new Intent(context, Detailspageloan.class).putExtra("recmodel", arrayList2));
                    }});
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList1.size();
    }
}
