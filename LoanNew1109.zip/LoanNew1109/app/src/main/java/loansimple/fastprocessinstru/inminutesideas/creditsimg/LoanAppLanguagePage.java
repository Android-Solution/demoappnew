package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import static loansimple.fastprocessinstru.inminutesideas.creditsimg.MyApp.getvaluepre;
import static loansimple.fastprocessinstru.inminutesideas.creditsimg.MyApp.show_exit_dialog;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.nativead.NativeAd;

import java.util.ArrayList;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.Cashinflatefb;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class LoanAppLanguagePage extends BaseActivity_Lang {
    ArrayList<Model_Language> LanguageList1;
    TextView savelang;
    String Lang_pref;
    public void backkk(View view) {
        Log.e("dd", "");

        onBackPressed();


    }
    @Override
    public void onBackPressed() {
        MyApp.show_ad(LoanAppLanguagePage.this, new CashonAdListner() {
            @Override
            public void onsuccess() {
                show_exit_dialog(LoanAppLanguagePage.this);
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loan_app_language_page);
        //banner
        String bb = MyApp.nativeAd(LoanAppLanguagePage.this);

        if (bb.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(LoanAppLanguagePage.this).is_ad_status()) {
                String id_banner = CashAppManager.getInstance(LoanAppLanguagePage.this).get_amob_banner_id();

                if (!id_banner.equalsIgnoreCase("")) {
                    AdView adView = new AdView(this);
                    adView.setAdSize(AdSize.BANNER);
                    adView.setAdUnitId(id_banner);
                    LinearLayout succes_banner = findViewById(R.id.succes_banner);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                    succes_banner.addView(adView);
                }
            }
        } else if (bb.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(LoanAppLanguagePage.this).is_ad_status_fb()) {
                LinearLayout succes_banner = findViewById(R.id.succes_banner);
                String id_banner = CashAppManager.getInstance(LoanAppLanguagePage.this).get_fb_banner_id();
                com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, id_banner, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                succes_banner.addView(adView);
                adView.loadAd();
            }
        }
        ///end

        //Nativee
        String aa = MyApp.nativeAd(LoanAppLanguagePage.this);
        TemplateView template = findViewById(R.id.my_template_success);
        template.setVisibility(View.INVISIBLE);
        if (aa.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(LoanAppLanguagePage.this).is_ad_status_Admob()) {

                String id_nativ = CashAppManager.getInstance(LoanAppLanguagePage.this).get_amob_nativ_id();

                if (!id_nativ.equalsIgnoreCase("")) {

                    AdLoader adLoader = new AdLoader.Builder(this, id_nativ)
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(NativeAd nativeAd) {
                                    template.setVisibility(View.VISIBLE);
                                    NativeTemplateStyle styles = new
                                            NativeTemplateStyle.Builder().build();

                                    template.setStyles(styles);
                                    template.setNativeAd(nativeAd);
                                }
                            })
                            .build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
        } else if (aa.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(LoanAppLanguagePage.this).is_ad_status_fb()) {
                template.removeAllViews();

                com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(this, CashAppManager.getInstance(LoanAppLanguagePage.this).get_amob_facebook_id());

                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        new Cashinflatefb().inflatefb(nativeAd, template, LoanAppLanguagePage.this);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                // Request an ad
                nativeAd.loadAd(
                        nativeAd.buildLoadAdConfig()
                                .withAdListener(nativeAdListener)
                                .build());


            }
        }
        ArrayList<Model_Language> arrayList = new ArrayList<>();
        RecyclerView recycler_loan_lang = findViewById(R.id.recycler_loan_lang);
        savelang = findViewById(R.id.savelang);
        savelang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApp.show_ad(LoanAppLanguagePage.this, new CashonAdListner() {
                    @Override
                    public void onsuccess() {
                        startActivity(new Intent(LoanAppLanguagePage.this, NextFirstPage.class));
                    }});
            }
        });
        this.Lang_pref = getvaluepre("lang_code", "en");
        this.LanguageList1 = arrayList;
        LanguageList1.add(new Model_Language("English", "en", R.drawable.lang_btn_eng));
        this.LanguageList1.add(new Model_Language("Hindi", "hi", R.drawable.lang_btn_hindi));
        this.LanguageList1.add(new Model_Language("Marathi", "mr", R.drawable.marathi));
        this.LanguageList1.add(new Model_Language("Gujarati", "gu", R.drawable.lang_btn_marathi));
        recycler_loan_lang.setLayoutManager(new GridLayoutManager(this, 2));
        Adapter_Language languageAdapter2 = new Adapter_Language(this, Lang_pref, LanguageList1);
        recycler_loan_lang.setAdapter(languageAdapter2);


    }


}