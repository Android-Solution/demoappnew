package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.nativead.NativeAd;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.Cashinflatefb;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class ooptryfoemfill extends BaseActivity_Lang {
    public void backkk(View view) {
        Log.e("dd", "");

        onBackPressed();


    }
    @Override
    public void onBackPressed() {
        MyApp.show_ad(ooptryfoemfill.this, new CashonAdListner() {
            @Override
            public void onsuccess() {
                ooptryfoemfill.super.onBackPressed();

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ooptryfoemfill);
        //banner
        String bb = MyApp.nativeAd(ooptryfoemfill.this);

        if (bb.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(ooptryfoemfill.this).is_ad_status()) {
                String id_banner = CashAppManager.getInstance(ooptryfoemfill.this).get_amob_banner_id();

                if (!id_banner.equalsIgnoreCase("")) {
                    AdView adView = new AdView(this);
                    adView.setAdSize(AdSize.BANNER);
                    adView.setAdUnitId(id_banner);
                    LinearLayout succes_banner = findViewById(R.id.succes_banner);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                    succes_banner.addView(adView);
                }
            }
        } else if (bb.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(ooptryfoemfill.this).is_ad_status_fb()) {
                LinearLayout succes_banner = findViewById(R.id.succes_banner);
                String id_banner = CashAppManager.getInstance(ooptryfoemfill.this).get_fb_banner_id();
                com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, id_banner, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                succes_banner.addView(adView);
                adView.loadAd();
            }
        }
        ///end

        //Nativee
        String aa = MyApp.nativeAd(ooptryfoemfill.this);
        TemplateView template = findViewById(R.id.my_template_success);
        template.setVisibility(View.INVISIBLE);
        if (aa.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(ooptryfoemfill.this).is_ad_status_Admob()) {

                String id_nativ = CashAppManager.getInstance(ooptryfoemfill.this).get_amob_nativ_id();

                if (!id_nativ.equalsIgnoreCase("")) {

                    AdLoader adLoader = new AdLoader.Builder(this, id_nativ)
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(NativeAd nativeAd) {
                                    template.setVisibility(View.VISIBLE);
                                    NativeTemplateStyle styles = new
                                            NativeTemplateStyle.Builder().build();

                                    template.setStyles(styles);
                                    template.setNativeAd(nativeAd);
                                }
                            })
                            .build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
        } else if (aa.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(ooptryfoemfill.this).is_ad_status_fb()) {
                template.removeAllViews();

                com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(this, CashAppManager.getInstance(ooptryfoemfill.this).get_amob_facebook_id());

                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        new Cashinflatefb().inflatefb(nativeAd, template, ooptryfoemfill.this);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                // Request an ad
                nativeAd.loadAd(
                        nativeAd.buildLoadAdConfig()
                                .withAdListener(nativeAdListener)
                                .build());


            }
        }

        ///
        (findViewById(R.id.btn_next)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyApp.show_ad(ooptryfoemfill.this, new CashonAdListner() {
                    @Override
                    public void onsuccess() {
                        startActivity(new Intent(ooptryfoemfill.this, FillFormfirstintro_loan.class));
                    }});

            }
        });
    }
}