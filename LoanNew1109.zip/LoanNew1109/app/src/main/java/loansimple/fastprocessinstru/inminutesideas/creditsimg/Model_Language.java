package loansimple.fastprocessinstru.inminutesideas.creditsimg;

public class Model_Language {
    int flag_image1;
    String language_code1;
    String language_name1;

    public Model_Language(String str, String str2, int i) {
        this.language_name1 = str;
        this.language_code1 = str2;
        this.flag_image1 = i;
    }

    public String getLanguage_name() {
        return this.language_name1;
    }

    public void setLanguage_name(String str) {
        this.language_name1 = str;
    }

    public String getLanguage_code() {
        return this.language_code1;
    }

    public void setLanguage_code(String str) {
        this.language_code1 = str;
    }

    public int getFlag_image() {
        return this.flag_image1;
    }

    public void setFlag_image(int i) {
        this.flag_image1 = i;
    }
}
