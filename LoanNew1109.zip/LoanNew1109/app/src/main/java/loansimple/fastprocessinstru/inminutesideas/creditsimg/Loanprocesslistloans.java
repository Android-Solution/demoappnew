package loansimple.fastprocessinstru.inminutesideas.creditsimg;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.NativeAdListener;
import com.google.android.ads.nativetemplates.NativeTemplateStyle;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashAppManager;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.Cashinflatefb;
import loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata.CashonAdListner;

public class Loanprocesslistloans extends BaseActivity_Lang {
    public void backkk(View view) {
        Log.e("dd", "");

        onBackPressed();


    }

    @Override
    public void onBackPressed() {
        MyApp.show_ad(Loanprocesslistloans.this, new CashonAdListner() {
            @Override
            public void onsuccess() {
                Loanprocesslistloans.super.onBackPressed();

            }
        });
    }

    public void show_help_dialog() {

        BottomSheetDialog dialog1 = new BottomSheetDialog(this);


        View view1 = getLayoutInflater().inflate(R.layout.help_dialog1, null);

        dialog1.setContentView(view1);


        TextView yes;
        ImageView close;

        yes = view1.findViewById(R.id.help_btn);
        close = view1.findViewById(R.id.closee);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog1.dismiss();
            }
        });

        yes.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                dialog1.dismiss();
                String Valuee = "Some Error";
                EditText editText = ((EditText) view1.findViewById(R.id.emailid_edi));
                if (editText.getText().toString().length() < 0) {
                    Valuee = "Enter Valid Email Id";
                } else {
                    EditText editText2 = (EditText) view1.findViewById(R.id.desc_query);
                    if (editText2.getText().toString().length() < 5) {
                        Valuee = "Enter Valid Description Query";
                    } else {
                        editText.setText("");
                        editText2.setText("");
                        Valuee = "Thanks For Your Query";
                    }
                }
                Toast.makeText(Loanprocesslistloans.this, Valuee, 0).show();
            }
        });

        dialog1.show();

    }

    public static void createInstanceOfClass(Activity activity, Class className, String key, String Valueofextra) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        MyApp.show_ad(activity, new CashonAdListner() {
            @Override
            public void onsuccess() {
                activity.startActivity(new Intent(activity, className).putExtra(key, Valueofextra));
            }
        });


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loanprocesslistloans);
        String aa = MyApp.nativeAd(Loanprocesslistloans.this);
        TemplateView template = findViewById(R.id.my_template_success);
        template.setVisibility(View.INVISIBLE);
        String bb = MyApp.nativeAd(Loanprocesslistloans.this);

        if (bb.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(Loanprocesslistloans.this).is_ad_status()) {
                String id_banner = CashAppManager.getInstance(Loanprocesslistloans.this).get_amob_banner_id();

                if (!id_banner.equalsIgnoreCase("")) {
                    AdView adView = new AdView(this);
                    adView.setAdSize(AdSize.BANNER);
                    adView.setAdUnitId(id_banner);
                    LinearLayout succes_banner = findViewById(R.id.succes_banner);
                    AdRequest adRequest = new AdRequest.Builder().build();
                    adView.loadAd(adRequest);
                    succes_banner.addView(adView);
                }
            }
        } else if (bb.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(Loanprocesslistloans.this).is_ad_status_fb()) {
                LinearLayout succes_banner = findViewById(R.id.succes_banner);
                String id_banner = CashAppManager.getInstance(Loanprocesslistloans.this).get_fb_banner_id();
                com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, id_banner, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
                succes_banner.addView(adView);
                adView.loadAd();
            }
        }
        ///end
        if (aa.equalsIgnoreCase("Admob")) {
            if (CashAppManager.getInstance(Loanprocesslistloans.this).is_ad_status_Admob()) {

                String id_nativ = CashAppManager.getInstance(Loanprocesslistloans.this).get_amob_nativ_id();

                if (!id_nativ.equalsIgnoreCase("")) {

                    AdLoader adLoader = new AdLoader.Builder(this, id_nativ)
                            .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
                                @Override
                                public void onNativeAdLoaded(NativeAd nativeAd) {
                                    template.setVisibility(View.VISIBLE);
                                    NativeTemplateStyle styles = new
                                            NativeTemplateStyle.Builder().build();

                                    template.setStyles(styles);
                                    template.setNativeAd(nativeAd);
                                }
                            })
                            .build();

                    adLoader.loadAd(new AdRequest.Builder().build());
                }
            }
        } else if (aa.equalsIgnoreCase("Facebook")) {
            if (CashAppManager.getInstance(Loanprocesslistloans.this).is_ad_status_fb()) {
                template.removeAllViews();

                com.facebook.ads.NativeAd nativeAd = new com.facebook.ads.NativeAd(this, CashAppManager.getInstance(Loanprocesslistloans.this).get_amob_facebook_id());

                NativeAdListener nativeAdListener = new NativeAdListener() {
                    @Override
                    public void onMediaDownloaded(Ad ad) {
                    }

                    @Override
                    public void onError(Ad ad, AdError adError) {
                    }

                    @Override
                    public void onAdLoaded(Ad ad) {
                        new Cashinflatefb().inflatefb(nativeAd, template, Loanprocesslistloans.this);
                    }

                    @Override
                    public void onAdClicked(Ad ad) {
                    }

                    @Override
                    public void onLoggingImpression(Ad ad) {
                    }
                };

                // Request an ad
                nativeAd.loadAd(
                        nativeAd.buildLoadAdConfig()
                                .withAdListener(nativeAdListener)
                                .build());


            }
        }
        (findViewById(R.id.helpp)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show_help_dialog();
            }
        });
        (findViewById(R.id.personal)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    createInstanceOfClass(Loanprocesslistloans.this, veriloandetails.class, "posii", "1");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        });
        (findViewById(R.id.homee)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    createInstanceOfClass(Loanprocesslistloans.this, veriloandetails.class, "posii", "2");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        });
        (findViewById(R.id.carr)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    createInstanceOfClass(Loanprocesslistloans.this, veriloandetails.class, "posii", "3");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        });
        (findViewById(R.id.business)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    createInstanceOfClass(Loanprocesslistloans.this, veriloandetails.class, "posii", "4");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}