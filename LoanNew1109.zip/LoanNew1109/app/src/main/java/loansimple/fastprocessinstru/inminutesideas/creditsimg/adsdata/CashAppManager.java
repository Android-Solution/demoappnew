package loansimple.fastprocessinstru.inminutesideas.creditsimg.adsdata;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;

import com.appsflyer.AppsFlyerLib;
import com.appsflyer.attribution.AppsFlyerRequestListener;
import com.facebook.FacebookSdk;
import com.facebook.LoggingBehavior;

import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;

import loansimple.fastprocessinstru.inminutesideas.creditsimg.MyApp;


public class CashAppManager {

    private static CashAppManager mInstance;
    static Activity activity;

    static Activity activity_nb;
    public static int count_click = -1;
    public static int count_click_nativ = -1;
    public static int count_click_banner = -1;
    public static int count_click_for_alt = -1;

    public static boolean STATUS;

    public static int updateAppDialogStatus = 0;
    public static String versionCode = "";
    public static int redirectOtherAppStatus = 0;
    public static String redirectUrl = "";
    public static int dialogBeforeAdShow = 0;
    public static int adShowStatus = 0;
    public static int howShowAd = 1;
    public static int isAdPreload_ins = 0;
    public static int isAdPreload_nb = 0;
    public static String adPlatformSequence = "";
    public static int mainClickCntSwAd = 0;
    public static int actual_main_click = 0;
    public static int innerClickCntSwAd = 0;
    public static int backClickCntSwAd = 0;
    public static int bannerlickCntSwAd = 0;
    public static int nativeClickCntSwAd = 0;

    public static int ADMOB_AD_STATUS = 0;
    public static String ADMOB_APPID = "";
    public static String ADMOB_APPOPEN_1 = "";
    public static String ADMOB_APPOPEN_2 = "";
    public static String ADMOB_INS_1 = "";
    public static String ADMOB_INS_2 = "";
    public static String ADMOB_NATIV_1 = "";
    public static String ADMOB_NATIV_2 = "";
    public static String ADMOB_BANNER_1 = "";
    public static String ADMOB_BANNER_2 = "";
    public static String ADMOB_REWARDED_1 = "";
    public static String ADMOB_REWARDED_2 = "";
    public static String ADMOB_OTHER_1 = "";
    public static String ADMOB_OTHER_2 = "";

    public static int FACEBOOK_AD_STATUS = 0;
    public static String FACEBOOK_APPID = "";
    public static String FACEBOOK_INS_1 = "";
    public static String FACEBOOK_INS_2 = "";
    public static String FACEBOOK_NATIV_1 = "";
    public static String FACEBOOK_NATIV_2 = "";
    public static String FACEBOOK_BANNER_1 = "";
    public static String FACEBOOK_BANNER_2 = "";
    public static String FACEBOOK_REWARDED_1 = "";
    public static String FACEBOOK_REWARDED_2 = "";
    public static String FACEBOOK_OTHER_1 = "";
    public static String FACEBOOK_OTHER_2 = "";

    public static int STARTAPP_AD_STATUS = 0;
    public static String STARTAPP_APPID = "";
    public static String STARTAPP_OTHER_1 = "";
    public static String STARTAPP_OTHER_2 = "";

    public static int LINK_AD_STATUS = 0;
    public static String LINK_AD_URL1 = "";
    public static String LINK_AD_URL2 = "";
    public static String LINK_AD_LOGO_1 = "";
    public static String LINK_AD_LOGO_2 = "";
    public static String LINK_AD_TITLE_1 = "";
    public static String LINK_AD_TITLE_2 = "";
    public static String LINK_AD_DESC_1 = "";
    public static String LINK_AD_DESC_2 = "";
    public static String LINK_AD_BANNER_P_1 = "";
    public static String LINK_AD_BANNER_P_2 = "";
    public static String LINK_AD_BANNER_H_1 = "";
    public static String LINK_AD_BANNER_H_2 = "";
    public static String LINK_AD_OTHER_1 = "";
    public static String LINK_AD_OTHER_2 = "";
    public static String AdGif1 = "";
    public static String AdGif2 = "";

    public static SharedPreferences mysharedpreferences;
    public static SharedPreferences.Editor editor;

    private InterstitialAd admob_ins1, admob_ins2, admob_ins3;

    String ad_url;
    View ad_view;
    Object pre_banner, pre_logo;
    Object pre_banner_nativ, pre_logo_nativ;
    com.google.android.gms.ads.nativead.NativeAd abmob_nativ1, abmob_nativ2, abmob_nativ3;
    com.google.android.gms.ads.nativead.NativeAd abmob_banner1, abmob_banner2, abmob_banner3;


    static MyCallback myCallback;
    private boolean is_foursesully;
    private ArrayList<String> interstitial_sequence;
    private ArrayList<String> native_sequence;
    private int count_native = -1;
    private ArrayList<String> banner_sequence;
    private int count_banner = -1;
    private int time_ad_dialog = 2;


    public interface MyCallback {
        void callbackCall();
    }

    public static CashAppManager getInstance(Activity activity) {
        activity_nb = activity;
        if (mInstance == null) {
            mInstance = new CashAppManager(activity);
        }
        return mInstance;
    }

    public CashAppManager(Activity activity) {
        activity_nb = activity;
        CashAppManager.activity = activity;
        mysharedpreferences = activity.getSharedPreferences(activity.getPackageName(), Context.MODE_PRIVATE);
        editor = mysharedpreferences.edit();
        getResponseFromPref();
    }


    public void getResponseFromPref(CashgetDataListner listner, int vcode) {
        String response1 = mysharedpreferences.getString("response", "");
        if (!response1.isEmpty()) {


            try {
                Log.e("my_log", "onResponse: " + "enter1111");
                JSONObject response = new JSONObject(response1);
                JSONObject settingsJsonObject = response.getJSONObject("APP_SETTINGS");

                STATUS = response.getBoolean("STATUS");

                updateAppDialogStatus = settingsJsonObject.getInt("updateAppDialogStatus");
                versionCode = settingsJsonObject.getString("versionCode");
                redirectOtherAppStatus = settingsJsonObject.getInt("redirectOtherAppStatus");
                redirectUrl = settingsJsonObject.getString("redirectUrl");
                dialogBeforeAdShow = settingsJsonObject.getInt("dialogBeforeAdShow");
                adShowStatus = settingsJsonObject.getInt("adShowStatus");
                howShowAd = settingsJsonObject.getInt("howShowAd");
                isAdPreload_ins = settingsJsonObject.getInt("isAdPreload_ins");
                isAdPreload_nb = settingsJsonObject.getInt("isAdPreload_nb");
                adPlatformSequence = settingsJsonObject.getString("adPlatformSequence");
                mainClickCntSwAd = settingsJsonObject.getInt("mainClickCntSwAd");
                innerClickCntSwAd = settingsJsonObject.getInt("innerClickCntSwAd");
                backClickCntSwAd = settingsJsonObject.getInt("backClickCntSwAd");
                bannerlickCntSwAd = settingsJsonObject.getInt("bannerlickCntSwAd");
                nativeClickCntSwAd = settingsJsonObject.getInt("nativeClickCntSwAd");


                SharedPreferences.Editor editor = mysharedpreferences.edit();
                editor.putInt("updateAppDialogStatus", updateAppDialogStatus).apply();
                editor.putString("versionCode", versionCode).apply();
                editor.putInt("redirectOtherAppStatus", redirectOtherAppStatus).apply();
                editor.putString("redirectUrl", redirectUrl).apply();
                editor.putInt("dialogBeforeAdShow", dialogBeforeAdShow).apply();
                editor.putInt("adShowStatus", adShowStatus).apply();
                editor.putInt("howShowAd", howShowAd).apply();
                editor.putInt("isAdPreload_ins", isAdPreload_ins).apply();
                editor.putInt("isAdPreload_nb", isAdPreload_nb).apply();
                editor.putString("adPlatformSequence", adPlatformSequence).apply();
                editor.putInt("mainClickCntSwAd", mainClickCntSwAd).apply();
                editor.putInt("innerClickCntSwAd", innerClickCntSwAd).apply();
                editor.putInt("backClickCntSwAd", backClickCntSwAd).apply();
                editor.putInt("bannerlickCntSwAd", bannerlickCntSwAd).apply();
                editor.putInt("nativeClickCntSwAd", nativeClickCntSwAd).apply();


                JSONObject AdmobJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("Admob");
                ADMOB_AD_STATUS = AdmobJsonObject.getInt("ad_showAdStatus");
                ADMOB_APPID = AdmobJsonObject.getString("AppID");
                ADMOB_APPOPEN_1 = AdmobJsonObject.getString("Appopen1");
                ADMOB_APPOPEN_2 = AdmobJsonObject.getString("Appopen2");
                ADMOB_INS_1 = AdmobJsonObject.getString("Interstitial1");
                ADMOB_INS_2 = AdmobJsonObject.getString("Interstitial2");
                ADMOB_NATIV_1 = AdmobJsonObject.getString("Native1");
                ADMOB_NATIV_2 = AdmobJsonObject.getString("Native2");
                ADMOB_BANNER_1 = AdmobJsonObject.getString("Banner1");
                ADMOB_BANNER_2 = AdmobJsonObject.getString("Banner2");
                ADMOB_REWARDED_1 = AdmobJsonObject.getString("RewardedVideo1");
                ADMOB_REWARDED_2 = AdmobJsonObject.getString("RewardedVideo2");
                ADMOB_OTHER_1 = AdmobJsonObject.getString("OtherId1");
                ADMOB_OTHER_2 = AdmobJsonObject.getString("OtherId2");

                JSONObject FacebookJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("Facebook");
                FACEBOOK_AD_STATUS = FacebookJsonObject.getInt("ad_showAdStatus");
                FACEBOOK_APPID = FacebookJsonObject.getString("AppID");
                FACEBOOK_INS_1 = FacebookJsonObject.getString("Interstitial1");
                FACEBOOK_INS_2 = FacebookJsonObject.getString("Interstitial2");
                FACEBOOK_NATIV_1 = FacebookJsonObject.getString("Native1");
                FACEBOOK_NATIV_2 = FacebookJsonObject.getString("Native2");
                FACEBOOK_BANNER_1 = FacebookJsonObject.getString("Banner1");
                FACEBOOK_BANNER_2 = FacebookJsonObject.getString("Banner2");
                FACEBOOK_REWARDED_1 = FacebookJsonObject.getString("RewardedVideo1");
                FACEBOOK_REWARDED_2 = FacebookJsonObject.getString("RewardedVideo2");
                FACEBOOK_OTHER_1 = FacebookJsonObject.getString("OtherId1");
                FACEBOOK_OTHER_2 = FacebookJsonObject.getString("OtherId2");

                JSONObject StartappJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("StartApp");
                STARTAPP_AD_STATUS = StartappJsonObject.getInt("ad_showAdStatus");
                STARTAPP_APPID = StartappJsonObject.getString("AppID");
                STARTAPP_OTHER_1 = StartappJsonObject.getString("OtherId1");
                STARTAPP_OTHER_2 = StartappJsonObject.getString("OtherId2");

                JSONObject LinkadJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("Link_Ad");
                LINK_AD_STATUS = LinkadJsonObject.getInt("ad_showAdStatus");
                LINK_AD_URL1 = LinkadJsonObject.getString("Link1");
                LINK_AD_URL2 = LinkadJsonObject.getString("Link2");
                LINK_AD_LOGO_1 = LinkadJsonObject.getString("AdLogo1");
                LINK_AD_LOGO_2 = LinkadJsonObject.getString("AdLogo2");
                LINK_AD_TITLE_1 = LinkadJsonObject.getString("AdText1");
                LINK_AD_TITLE_2 = LinkadJsonObject.getString("AdText2");
                LINK_AD_DESC_1 = LinkadJsonObject.getString("Description1");
                LINK_AD_DESC_2 = LinkadJsonObject.getString("Description2");
                LINK_AD_BANNER_P_1 = LinkadJsonObject.getString("AdBannerP1");
                LINK_AD_BANNER_P_2 = LinkadJsonObject.getString("AdBannerP2");
                LINK_AD_BANNER_H_1 = LinkadJsonObject.getString("AdBannerH1");
                LINK_AD_BANNER_H_2 = LinkadJsonObject.getString("AdBannerH2");
                LINK_AD_OTHER_1 = LinkadJsonObject.getString("OtherId1");
                LINK_AD_OTHER_2 = LinkadJsonObject.getString("OtherId2");
                AdGif1 = LinkadJsonObject.getString("AdGif1");
                AdGif2 = LinkadJsonObject.getString("AdGif2");
                try {
                    listner.ongetExtradata(response.getJSONObject("EXTRA_DATA"));
                } catch (Exception e) {

                }
                if (!FACEBOOK_APPID.equalsIgnoreCase("") && !FACEBOOK_OTHER_1.equalsIgnoreCase("")) {
                    FacebookSdk.setApplicationId(FACEBOOK_APPID);
                    FacebookSdk.setClientToken(FACEBOOK_OTHER_1);
                    FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
                }


            } catch (Exception e) {
                Log.e("my_log_respones", "getResponseFromPref: " + e.getMessage());
            }


            if (redirectOtherAppStatus == 1) {
                String redirectNewPackage = mysharedpreferences.getString("redirectUrl", "");
                listner.onRedirect(redirectNewPackage);
            } else if (updateAppDialogStatus == 1 && !checkUpdate(vcode)) {
                listner.onUpdate("https://play.google.com/store/apps/details?id=" + activity.getPackageName());
            } else {
                listner.onsuccess();
                initAd(activity);
                if (myCallback != null) {
                    myCallback.callbackCall();
                    myCallback = null;
                }

            }
        }


    }

    private static boolean checkUpdate(int vcode) {


        if (mysharedpreferences.getInt("app_updateAppDialogStatus", 0) == 1) {
            String versions = mysharedpreferences.getString("app_versionCode", "");
            String str[] = versions.split(",");

            try {
                int cversion = vcode;

                if (Arrays.asList(str).contains(cversion + "")) {
                    return true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return false;
    }

    private void initAd(Activity activity) {

        if (!STARTAPP_APPID.equalsIgnoreCase("")) {
            AppsFlyerLib.getInstance().init(STARTAPP_APPID, null, activity);
            AppsFlyerLib.getInstance().start(activity,STARTAPP_APPID, new AppsFlyerRequestListener() {
                @Override
                public void onSuccess() {
                }

                @Override
                public void onError(int i, @NonNull String s) {
                }
            });
        }

        if (ADMOB_AD_STATUS == 1) {
            MobileAds.initialize(activity, new OnInitializationCompleteListener() {
                @Override
                public void onInitializationComplete(InitializationStatus initializationStatus) {


                }
            });
            SharedPreferences preferences = activity.getSharedPreferences("click_pref", 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putInt("ins_click", CashAppManager.getInstance(activity).get_mailclcik_count()).apply();
            MyApp.load_ad(activity);
        }
        if (!FACEBOOK_APPID.equalsIgnoreCase("") && !FACEBOOK_OTHER_1.equalsIgnoreCase("")) {
            FacebookSdk.setApplicationId(FACEBOOK_APPID);
            FacebookSdk.setClientToken(FACEBOOK_OTHER_1);
            FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
        }

        if (FACEBOOK_AD_STATUS == 1) {
            AudienceNetworkAds.initialize(activity);
            MyApp.load_adfb(activity);

        }

    }


    public static void getResponseFromPref() {
        String response1 = mysharedpreferences.getString("response", "");
        if (!response1.isEmpty()) {
            try {
                JSONObject response = new JSONObject(response1);
                JSONObject settingsJsonObject = response.getJSONObject("APP_SETTINGS");


                STATUS = response.getBoolean("STATUS");


                updateAppDialogStatus = settingsJsonObject.getInt("updateAppDialogStatus");
                versionCode = settingsJsonObject.getString("versionCode");
                redirectOtherAppStatus = settingsJsonObject.getInt("redirectOtherAppStatus");
                redirectUrl = settingsJsonObject.getString("redirectUrl");
                dialogBeforeAdShow = settingsJsonObject.getInt("dialogBeforeAdShow");
                adShowStatus = settingsJsonObject.getInt("adShowStatus");
                howShowAd = settingsJsonObject.getInt("howShowAd");
                isAdPreload_ins = settingsJsonObject.getInt("isAdPreload_ins");
                isAdPreload_nb = settingsJsonObject.getInt("isAdPreload_nb");
                adPlatformSequence = settingsJsonObject.getString("adPlatformSequence");
                mainClickCntSwAd = settingsJsonObject.getInt("mainClickCntSwAd");
                innerClickCntSwAd = settingsJsonObject.getInt("innerClickCntSwAd");
                backClickCntSwAd = settingsJsonObject.getInt("backClickCntSwAd");
                bannerlickCntSwAd = settingsJsonObject.getInt("bannerlickCntSwAd");
                nativeClickCntSwAd = settingsJsonObject.getInt("nativeClickCntSwAd");


                SharedPreferences.Editor editor = mysharedpreferences.edit();
                editor.putInt("updateAppDialogStatus", updateAppDialogStatus).apply();
                editor.putString("versionCode", versionCode).apply();
                editor.putInt("redirectOtherAppStatus", redirectOtherAppStatus).apply();
                editor.putString("redirectUrl", redirectUrl).apply();
                editor.putInt("dialogBeforeAdShow", dialogBeforeAdShow).apply();
                editor.putInt("adShowStatus", adShowStatus).apply();
                editor.putInt("howShowAd", howShowAd).apply();
                editor.putInt("isAdPreload_ins", isAdPreload_ins).apply();
                editor.putInt("isAdPreload_nb", isAdPreload_nb).apply();
                editor.putString("adPlatformSequence", adPlatformSequence).apply();
                editor.putInt("mainClickCntSwAd", mainClickCntSwAd).apply();
                editor.putInt("innerClickCntSwAd", innerClickCntSwAd).apply();
                editor.putInt("backClickCntSwAd", backClickCntSwAd).apply();
                editor.putInt("bannerlickCntSwAd", bannerlickCntSwAd).apply();
                editor.putInt("nativeClickCntSwAd", nativeClickCntSwAd).apply();


                JSONObject AdmobJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("Admob");
                ADMOB_AD_STATUS = AdmobJsonObject.getInt("ad_showAdStatus");
                ADMOB_APPID = AdmobJsonObject.getString("AppID");
                ADMOB_APPOPEN_1 = AdmobJsonObject.getString("Appopen1");
                ADMOB_APPOPEN_2 = AdmobJsonObject.getString("Appopen2");
                ADMOB_INS_1 = AdmobJsonObject.getString("Interstitial1");
                ADMOB_INS_2 = AdmobJsonObject.getString("Interstitial2");
                ADMOB_NATIV_1 = AdmobJsonObject.getString("Native1");
                ADMOB_NATIV_2 = AdmobJsonObject.getString("Native2");
                ADMOB_BANNER_1 = AdmobJsonObject.getString("Banner1");
                ADMOB_BANNER_2 = AdmobJsonObject.getString("Banner2");
                ADMOB_REWARDED_1 = AdmobJsonObject.getString("RewardedVideo1");
                ADMOB_REWARDED_2 = AdmobJsonObject.getString("RewardedVideo2");
                ADMOB_OTHER_1 = AdmobJsonObject.getString("OtherId1");
                ADMOB_OTHER_2 = AdmobJsonObject.getString("OtherId2");


                JSONObject FacebookJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("Facebook");
                FACEBOOK_AD_STATUS = FacebookJsonObject.getInt("ad_showAdStatus");
                FACEBOOK_APPID = FacebookJsonObject.getString("AppID");
                FACEBOOK_INS_1 = FacebookJsonObject.getString("Interstitial1");
                FACEBOOK_INS_2 = FacebookJsonObject.getString("Interstitial2");
                FACEBOOK_NATIV_1 = FacebookJsonObject.getString("Native1");
                FACEBOOK_NATIV_2 = FacebookJsonObject.getString("Native2");
                FACEBOOK_BANNER_1 = FacebookJsonObject.getString("Banner1");
                FACEBOOK_BANNER_2 = FacebookJsonObject.getString("Banner2");
                FACEBOOK_REWARDED_1 = FacebookJsonObject.getString("RewardedVideo1");
                FACEBOOK_REWARDED_2 = FacebookJsonObject.getString("RewardedVideo2");
                FACEBOOK_OTHER_1 = FacebookJsonObject.getString("OtherId1");
                FACEBOOK_OTHER_2 = FacebookJsonObject.getString("OtherId2");

                JSONObject StartappJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("StartApp");
                STARTAPP_AD_STATUS = StartappJsonObject.getInt("ad_showAdStatus");
                STARTAPP_APPID = StartappJsonObject.getString("AppID");
                STARTAPP_OTHER_1 = StartappJsonObject.getString("OtherId1");
                STARTAPP_OTHER_2 = StartappJsonObject.getString("OtherId2");

                JSONObject LinkadJsonObject = response.getJSONObject("PLACEMENT").getJSONObject("Link_Ad");
                LINK_AD_STATUS = LinkadJsonObject.getInt("ad_showAdStatus");
                LINK_AD_URL1 = LinkadJsonObject.getString("Link1");
                LINK_AD_URL2 = LinkadJsonObject.getString("Link2");
                LINK_AD_LOGO_1 = LinkadJsonObject.getString("AdLogo1");
                LINK_AD_LOGO_2 = LinkadJsonObject.getString("AdLogo2");
                LINK_AD_TITLE_1 = LinkadJsonObject.getString("AdText1");
                LINK_AD_TITLE_2 = LinkadJsonObject.getString("AdText2");
                LINK_AD_DESC_1 = LinkadJsonObject.getString("Description1");
                LINK_AD_DESC_2 = LinkadJsonObject.getString("Description2");
                LINK_AD_BANNER_P_1 = LinkadJsonObject.getString("AdBannerP1");
                LINK_AD_BANNER_P_2 = LinkadJsonObject.getString("AdBannerP2");
                LINK_AD_BANNER_H_1 = LinkadJsonObject.getString("AdBannerH1");
                LINK_AD_BANNER_H_2 = LinkadJsonObject.getString("AdBannerH2");
                LINK_AD_OTHER_1 = LinkadJsonObject.getString("OtherId1");
                LINK_AD_OTHER_2 = LinkadJsonObject.getString("OtherId2");
                AdGif1 = LinkadJsonObject.getString("AdGif1");
                AdGif2 = LinkadJsonObject.getString("AdGif2");


            } catch (Exception e) {
                Log.e("my_log_respones", "getResponseFromPref: " + e.getMessage());
            }

        }


    }

    public boolean is_appopen_avilable() {
        if (adShowStatus == 1 && ADMOB_AD_STATUS == 1 && !ADMOB_APPOPEN_1.isEmpty()) {
            return true;
        }
        return false;
    }

    public boolean is_ad_status() {
        if (adShowStatus == 1) {
            return true;
        }
        return false;
    }
    public boolean is_ad_status_Admob() {
        if (adShowStatus == 1&&ADMOB_AD_STATUS==1) {
            return true;
        }
        return false;
    }
    public boolean is_ad_status_fb() {
        if (adShowStatus == 1 && FACEBOOK_AD_STATUS == 1) {
            return true;
        }
        return false;
    }
    public String get_fb_ins_id() {
        String fb_i;
        if (mysharedpreferences.getInt("which_id_fb_ins", 0) == 0) {
            editor.putInt("which_id_fb_ins", 1).apply();
            fb_i = FACEBOOK_INS_1;
        } else {
            editor.putInt("which_id_fb_ins", 0).apply();
            fb_i = FACEBOOK_INS_2;
        }
        return fb_i;
    }
    public int get_mailclcik_count() {

        return mainClickCntSwAd;
    }

    public String get_amob_ins_id() {
        if (adShowStatus == 1 && ADMOB_AD_STATUS == 1 && !ADMOB_INS_1.isEmpty()) {
            String google_i;
            if (mysharedpreferences.getInt("which_id_admob_ins", 0) == 0) {
                editor.putInt("which_id_admob_ins", 1).apply();
                google_i = ADMOB_INS_1;
            } else {
                editor.putInt("which_id_admob_ins", 0).apply();
                google_i = ADMOB_INS_1;
            }
            return google_i;
        }
        return "";
    }

    public String get_amob_banner_id() {
        if (adShowStatus == 1 && ADMOB_AD_STATUS == 1 && !ADMOB_BANNER_1.isEmpty()) {
            String google_i;
            if (mysharedpreferences.getInt("which_id_admob_banner", 0) == 0) {
                editor.putInt("which_id_admob_banner", 1).apply();
                google_i = ADMOB_BANNER_1;
            } else {
                editor.putInt("which_id_admob_banner", 0).apply();
                google_i = ADMOB_BANNER_2;
            }
            return google_i;
        }
        return "";
    }

    public String get_fb_banner_id() {
        if (adShowStatus == 1 && FACEBOOK_AD_STATUS == 1 && !FACEBOOK_BANNER_1.isEmpty()) {
            String google_i;
            if (mysharedpreferences.getInt("which_id_fb_banner", 0) == 0) {
                editor.putInt("which_id_fb_banner", 1).apply();
                google_i = FACEBOOK_BANNER_1;
            } else {
                editor.putInt("which_id_fb_banner", 0).apply();
                google_i = FACEBOOK_BANNER_2;
            }
            return google_i;
        }
        return "";
    }
    public String get_amob_nativ_id() {
        if (adShowStatus == 1 && ADMOB_AD_STATUS == 1 && !ADMOB_NATIV_1.isEmpty()) {
            String google_i;
            if (mysharedpreferences.getInt("which_id_admob_nativ", 0) == 0) {
                editor.putInt("which_id_admob_nativ", 1).apply();
                google_i = ADMOB_NATIV_1;
            } else {
                editor.putInt("which_id_admob_nativ", 0).apply();
                google_i = ADMOB_NATIV_2;
            }
            return google_i;
        }
        return "";
    }

    public String get_amob_facebook_id() {
        if (adShowStatus == 1 && FACEBOOK_AD_STATUS == 1 && !FACEBOOK_NATIV_1.isEmpty()) {
            String google_i;
            if (mysharedpreferences.getInt("which_id_fb_nativ", 0) == 0) {
                editor.putInt("which_id_fb_nativ", 1).apply();
                google_i = FACEBOOK_NATIV_1;
            } else {
                editor.putInt("which_id_fb_nativ", 0).apply();
                google_i = FACEBOOK_NATIV_2;
            }
            return google_i;
        }
        return "";
    }

    public String get_amob_facebook_nb_id() {
        if (adShowStatus == 1 && FACEBOOK_AD_STATUS == 1 && !FACEBOOK_REWARDED_1.isEmpty()) {
            String google_i;
            if (mysharedpreferences.getInt("which_id_fb_nativ_banner", 0) == 0) {
                editor.putInt("which_id_fb_nativ_banner", 1).apply();
                google_i = FACEBOOK_REWARDED_1;
            } else {
                editor.putInt("which_id_fb_nativ_banner", 0).apply();
                google_i = FACEBOOK_REWARDED_2;
            }
            return google_i;
        }
        return "";
    }

    public String get_amob_appopen_id() {
        if (adShowStatus == 1 && ADMOB_AD_STATUS == 1 && !ADMOB_APPOPEN_1.isEmpty()) {
            String google_i;
            if (mysharedpreferences.getInt("which_id_admob_appopen", 0) == 0) {
                editor.putInt("which_id_admob_appopen", 1).apply();
                google_i = ADMOB_APPOPEN_1;
            } else {
                editor.putInt("which_id_admob_appopen", 0).apply();
                google_i = ADMOB_APPOPEN_2;
            }
            return google_i;
        }
        return "";
    }

    public static void rateapp(Context context, String packagename) {
        try {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + context.getPackageName())));
        } catch (ActivityNotFoundException e) {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + context.getPackageName())));
        }
    }

    public static void shareapp(Context c, String packagename, String Appname, String Bodytexy) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", Appname);
        intent.putExtra("android.intent.extra.TEXT", Bodytexy + "\nhttps://play.g   oogle.com/store/apps/details?id=" + packagename);
        intent.setType("text/plain");
        c.startActivity(Intent.createChooser(intent, "Share"));
    }
}
